class NoArv{
	public:
		int info;
		NoArv * esq;
		NoArv * dir;
	
	public:
		NoArv();
		NoArv(int i, NoArv * abb);
};
